# Plain Latex

A minimal template that only uses vanilla LaTeX commands and environments

<img src="thumbnail.png" />

- Author: Curvenote
- License: CC-BY-4.0
